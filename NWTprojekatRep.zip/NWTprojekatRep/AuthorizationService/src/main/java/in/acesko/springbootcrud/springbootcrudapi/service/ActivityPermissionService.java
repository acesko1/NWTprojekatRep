package in.acesko.springbootcrud.springbootcrudapi.service;

import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.ActivityPermission;

public interface ActivityPermissionService {
	
	List<ActivityPermission> get();
	ActivityPermission get(int id);
	void save(ActivityPermission activityPermission);
	void delete(int id);
}
