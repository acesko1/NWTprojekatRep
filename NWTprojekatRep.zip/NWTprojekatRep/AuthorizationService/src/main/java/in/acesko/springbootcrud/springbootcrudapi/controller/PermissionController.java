package in.acesko.springbootcrud.springbootcrudapi.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.acesko.springbootcrud.springbootcrudapi.model.Permission;

import in.acesko.springbootcrud.springbootcrudapi.service.PermissionService;

@RestController
@RequestMapping("/api")
public class PermissionController {

	@Autowired
	private PermissionService permissionService;
	
	@GetMapping("/dopustenja")
	public List<Permission> get(){
		return permissionService.get();
	}
	
	@PostMapping("/dopustenja")	
	public Permission save(@RequestBody Permission permission) {
		permissionService.save(permission);
		return permission;
	}
	
	@GetMapping("/dopustenja/{id}")
	public Permission get(@PathVariable int id) {
		Permission permission = permissionService.get(id);
		if(permission == null) {
			throw new RuntimeException("Dopuštenja sa id-om:"+id+"nisu pronađena");
		}
		return permission;
	}
	@DeleteMapping("/dopustenja/{id}")
	public String delete(@PathVariable int id) {
		permissionService.delete(id);
		return "Dopuštenja su obrisana sa id-om:"+id;
	}
	@PutMapping("/dopustenja")
	public Permission update(@RequestBody Permission permission) {
		permissionService.save(permission);
		return permission;
	}
//	@RequestMapping(value = "/dopustenja", method = RequestMethod.GET)
//	public Dopustenja firstPage() {
//
//		Dopustenja dopustenja = new Dopustenja();
//		dopustenja.setAzuriranaU(null);
//		dopustenja.setKreiranaU(null);
//		dopustenja.setDopustenjaID(1);
//		dopustenja.setNaziv("Naziv dopustenja");
//		return dopustenja;
//	}
	
}
