package in.acesko.springbootcrud.springbootcrudapi.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.acesko.springbootcrud.springbootcrudapi.model.ActivityPermission;
import in.acesko.springbootcrud.springbootcrudapi.service.ActivityPermissionService;

@RestController
@RequestMapping("/api")
public class AktivnostiDopustenjaController {

	@Autowired
	private ActivityPermissionService activityPermissionService;
	
	@GetMapping("/aktivnostiDopustenja")
	public List<ActivityPermission> get(){
		return activityPermissionService.get();
	}
	
	@PostMapping("/aktivnostiDopustenja")	
	public ActivityPermission save(@RequestBody ActivityPermission activityPermissionObj) {
		activityPermissionService.save(activityPermissionObj);
		return activityPermissionObj;
	}
	
	@GetMapping("/aktivnostiDopustenja/{id}")
	public ActivityPermission get(@PathVariable int id) {
		ActivityPermission activityPermissionObj = activityPermissionService.get(id);
		if(activityPermissionObj == null) {
			throw new RuntimeException("Aktivnosti-Dopustenja sa id-om:"+id+"nisu pronađeni");
		}
		return activityPermissionObj;
	}
	@DeleteMapping("/aktivnostiDopustenja/{id}")
	public String delete(@PathVariable int id) {
		activityPermissionService.delete(id);
		return "Aktivnosti-Dopuštenja su obrisani sa id-om:"+id;
	}
	@PutMapping("/aktivnostiDopustenja")
	public ActivityPermission update(@RequestBody ActivityPermission activityPermissionObj) {
		activityPermissionService.save(activityPermissionObj);
		return activityPermissionObj;
	}
//	@RequestMapping(value = "/aktivnostiDopustenja", method = RequestMethod.GET)
//	public AktivnostiDopustenja firstPage() {
//
//		AktivnostiDopustenja aktivnostiDopustenja = new AktivnostiDopustenja();
//		aktivnostiDopustenja.setAktivnostiDopustenjaID(1);
//		aktivnostiDopustenja.setAktivnostiID(1);
//		aktivnostiDopustenja.setDopustenjaID(1);
//
//		return aktivnostiDopustenja;
//	}
	
}
