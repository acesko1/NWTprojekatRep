package in.acesko.springbootcrud.springbootcrudapi.service;

import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.Permission;

public interface PermissionService {
	
	List<Permission> get();
	Permission get(int id);
	void save(Permission permission);
	void delete(int id);
}
