package in.acesko.springbootcrud.springbootcrudapi.service;

import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.Activity;

public interface ActivityService {
	
	List<Activity> get();
	Activity get(int id);
	void save(Activity activity);
	void delete(int id);
}
