package in.acesko.springbootcrud.springbootcrudapi.repository;


import in.acesko.springbootcrud.springbootcrudapi.model.ActivityPermission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActivityPermissionRepository extends JpaRepository<ActivityPermission,Integer> {
}
