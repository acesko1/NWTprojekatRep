package in.acesko.springbootcrud.springbootcrudapi.service;

import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.RolePermission;

public interface RolePermissionService {
	
	List<RolePermission> get();
	RolePermission get(int id);
	void save(RolePermission rolePermission);
	void delete(int id);
}

