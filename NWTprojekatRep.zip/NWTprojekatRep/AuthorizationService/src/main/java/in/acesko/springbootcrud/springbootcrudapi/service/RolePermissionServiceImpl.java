package in.acesko.springbootcrud.springbootcrudapi.service;

import in.acesko.springbootcrud.springbootcrudapi.repository.RolePermissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.acesko.springbootcrud.springbootcrudapi.model.RolePermission;
import java.util.List;

@Service
public class RolePermissionServiceImpl implements RolePermissionService {

	@Autowired
	private RolePermissionRepository rolePermissionRepository;
	
	@Transactional
	@Override
	public List<RolePermission> get() {
		return rolePermissionRepository.findAll();
	}

	@Transactional
	@Override
	public RolePermission get(int id) {
	return rolePermissionRepository.getOne(id);
	}

	@Transactional
	@Override
	public void save(RolePermission rolePermission) {
		rolePermissionRepository.save(rolePermission);
	}

	@Transactional
	@Override
	public void delete(int id) {
		rolePermissionRepository.deleteById(id);
	}

}
