package in.acesko.springbootcrud.springbootcrudapi.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import in.acesko.springbootcrud.springbootcrudapi.model.RolePermission;
import in.acesko.springbootcrud.springbootcrudapi.service.RolePermissionService;

@RestController
@RequestMapping("/api")
public class KorisnickaDopustenjaController {

	@Autowired
	private RolePermissionService rolePermissionService;
	
	@GetMapping("/korisnickaDopustenja")
	public List<RolePermission> get(){
		return  rolePermissionService.get();
	}
	
	@PostMapping("/korisnickaDopustenja")	
	public RolePermission save(@RequestBody RolePermission rolePermissionObj) {
		 rolePermissionService.save(rolePermissionObj);
		return rolePermissionObj;
	}
	
	@GetMapping("/korisnickaDopustenja/{id}")
	public RolePermission get(@PathVariable int id) {
		RolePermission rolePermissionObj =  rolePermissionService.get(id);
		if(rolePermissionObj == null) {
			throw new RuntimeException("Korisnička dopuštenja sa id-om:"+id+"nisu pronađena");
		}
		return rolePermissionObj;
	}
	@DeleteMapping("/korisnickaDopustenja/{id}")
	public String delete(@PathVariable int id) {
		 rolePermissionService.delete(id);
		return "Korisnička dopuštenja su obrisana sa id-om:"+id;
	}
	@PutMapping("/korisnickaDopustenja")
	public RolePermission update(@RequestBody RolePermission rolePermissionObj) {
		 rolePermissionService.save(rolePermissionObj);
		return rolePermissionObj;
	}
//	@RequestMapping(value = "/korisnickaDopustenja", method = RequestMethod.GET)
//	public KorisnickaDopustenja firstPage() {
//
//		KorisnickaDopustenja korisnickaDopustenja = new KorisnickaDopustenja();
//		korisnickaDopustenja.setDopustenjaID(1);
//		korisnickaDopustenja.setKorisnickaDopustenjaID(1);
//		korisnickaDopustenja.setUlogaID(1);
//
//		return korisnickaDopustenja;
//	}
	
}
