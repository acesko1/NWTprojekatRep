package com.nwt.witcher.paymentapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplyServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
