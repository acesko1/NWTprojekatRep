package in.acesko.springbootcrud.springbootcrudapi.service;

import in.acesko.springbootcrud.springbootcrudapi.repository.SalesItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.acesko.springbootcrud.springbootcrudapi.model.SalesItem;
import java.util.List;

@Service
public class SalesItemServiceImpl implements SalesItemService {

	@Autowired
	private SalesItemRepository salesItemRepository;
	
	@Transactional
	@Override
	public List<SalesItem> get() {
		return salesItemRepository.findAll();
	}

	@Transactional
	@Override
	public SalesItem get(int id) {
	return salesItemRepository.getOne(id);
	}

	@Transactional
	@Override
	public void save(SalesItem salesItem) {
		salesItemRepository.save(salesItem);
	}

	@Transactional
	@Override
	public void delete(int id) {
		salesItemRepository.deleteById(id);
	}

}
