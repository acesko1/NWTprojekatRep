package in.acesko.springbootcrud.springbootcrudapi.service;
import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.Product;

public interface ProductService {
	
	List<Product> get();
	Product get(int id);
	void save(Product product);
	void delete(int id);
}
