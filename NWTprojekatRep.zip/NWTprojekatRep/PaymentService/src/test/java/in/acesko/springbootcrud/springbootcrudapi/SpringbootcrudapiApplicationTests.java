package in.acesko.springbootcrud.springbootcrudapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcrudapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
