package in.acesko.springbootcrud.springbootcrudapi.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.acesko.springbootcrud.springbootcrudapi.model.Payment;
import in.acesko.springbootcrud.springbootcrudapi.service.PaymentService;

@RestController
@RequestMapping("/api")
public class PaymentController {

	@Autowired
	private PaymentService paymentService;
	
	@GetMapping("/naplata")
	public List<Payment> get(){
		return paymentService.get();
	}
	
	@PostMapping("/naplata")	
	public Payment save(@RequestBody Payment paymentObj) {
		paymentService.save(paymentObj);
		return paymentObj;
	}
	
	@GetMapping("/naplata/{id}")
	public Payment get(@PathVariable int id) {
		Payment paymentObj = paymentService.get(id);
		if(paymentObj == null) {
			throw new RuntimeException("Naplata sa id-om:"+id+"nije pronađena");
		}
		return paymentObj;
	}
	@DeleteMapping("/naplata/{id}")
	public String delete(@PathVariable int id) {
		paymentService.delete(id);
		return "Naplata je obrisana sa id-om:"+id;
	}
	@PutMapping("/naplata")
	public Payment update(@RequestBody Payment paymentObj) {
		paymentService.save(paymentObj);
		return paymentObj;
	}
//	@RequestMapping(value = "/naplata", method = RequestMethod.GET)
//	public Naplata firstPage() {
//
//		Naplata nap = new Naplata();
//		nap.setNaplataID(1);
//		nap.setKorisnikID(2);
//		nap.setOpis("Opis naplate");
//		nap.setStavkaProdajeID(1);
//		nap.setValuta("BAM");
//		nap.setAdresaDostave("Adresa 14");
//
//		return nap;
//	}
	
}
