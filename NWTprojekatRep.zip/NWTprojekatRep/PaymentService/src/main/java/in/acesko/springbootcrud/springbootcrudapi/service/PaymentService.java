package in.acesko.springbootcrud.springbootcrudapi.service;

import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.Payment;

public interface PaymentService {
	
	List<Payment> get();
	Payment get(int id);
	void save(Payment payment);
	void delete(int id);
}
