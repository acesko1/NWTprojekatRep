package in.acesko.springbootcrud.springbootcrudapi.service;

import in.acesko.springbootcrud.springbootcrudapi.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.acesko.springbootcrud.springbootcrudapi.model.Payment;
import java.util.List;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private PaymentRepository paymentRepository;
	
	@Transactional
	@Override
	public List<Payment> get() {
		return paymentRepository.findAll();
	}

	@Transactional
	@Override
	public Payment get(int id) {
	return paymentRepository.getOne(id);
	}

	@Transactional
	@Override
	public void save(Payment payment) {
		paymentRepository.save(payment);
	}

	@Transactional
	@Override
	public void delete(int id) {
		paymentRepository.deleteById(id);
	}
}
