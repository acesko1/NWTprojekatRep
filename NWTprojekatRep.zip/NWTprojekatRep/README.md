# NWTprojekatRep
Repozitorij za NWT - Projekat Webshop (grupa Witcher)
Svi mikroservisi se sastoje od 4 paketa: Controller, DAO, Model i Service, ne računajući glavni paket. Unutar paketa su napravljene klase. Controller paket za svaki entitet unutar servisa sadrži klasu Controller, DAO paket sadrži interfejs i implementirajuću klasu za svaki entitet, Model paket sadrži klasu model, Service paket sadrži interfejs i implementirajuću klasu. 
