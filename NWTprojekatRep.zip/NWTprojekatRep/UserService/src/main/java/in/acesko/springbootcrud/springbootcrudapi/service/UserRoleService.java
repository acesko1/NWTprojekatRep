package in.acesko.springbootcrud.springbootcrudapi.service;

import java.util.List;
import in.acesko.springbootcrud.springbootcrudapi.model.UserRole;

public interface UserRoleService {
	
	List<UserRole> get();
	UserRole get(int id);
	void save(UserRole userRole);
	void delete(int id);
}
