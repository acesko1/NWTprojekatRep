package in.acesko.springbootcrud.springbootcrudapi.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.acesko.springbootcrud.springbootcrudapi.model.UserRole;
import in.acesko.springbootcrud.springbootcrudapi.service.UserRoleService;

@RestController
@RequestMapping("/api")
public class UserRoleController {

	@Autowired
	private UserRoleService userRoleService;
	
	@GetMapping("/korisnickeRole")
	public List<UserRole> get(){
		return userRoleService.get();
	}
	
	@PostMapping("/korisnickeRole")	
	public UserRole save(@RequestBody UserRole userRoleObj) {
		userRoleService.save(userRoleObj);
		return userRoleObj;
	}
	
	@GetMapping("/korisnickeRole/{id}")
	public UserRole get(@PathVariable int id) {
		UserRole userRoleObj = userRoleService.get(id);
		if(userRoleObj == null) {
			throw new RuntimeException("Korisnicke role sa id-om:"+id+"nisu pronađene");
		}
		return userRoleObj;
	}
	@DeleteMapping("/korisnickeRole/{id}")
	public String delete(@PathVariable int id) {
		userRoleService.delete(id);
		return "Korisnicke role su obrisane sa id-om:"+id;
	}
	@PutMapping("/korisnickeRole")
	public UserRole update(@RequestBody UserRole userRoleObj) {
		userRoleService.save(userRoleObj);
		return userRoleObj;
	}
//	@RequestMapping(value = "/korisnickeRole", method = RequestMethod.GET)
//	public KorisnickeRole firstPage() {
//
//		KorisnickeRole korrol = new KorisnickeRole();
//		korrol.setKorisnickaRolaID(1);
//		korrol.setKorisnikID(1);
//		korrol.setRolaID(1);
//
//		return korrol;
//	}

	
}
