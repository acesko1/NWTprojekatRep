package in.acesko.springbootcrud.springbootcrudapi.service;

import in.acesko.springbootcrud.springbootcrudapi.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.acesko.springbootcrud.springbootcrudapi.model.UserRole;
import java.util.List;

@Service
public class UserRoleServiceImpl implements UserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepository;
	
	@Transactional
	@Override
	public List<UserRole> get() {
		return userRoleRepository.findAll();
	}

	@Transactional
	@Override
	public UserRole get(int id) {
	return userRoleRepository.getOne(id);
	}

	@Transactional
	@Override
	public void save(UserRole userRole) {
		userRoleRepository.save(userRole);
	}

	@Transactional
	@Override
	public void delete(int id) {
		userRoleRepository.deleteById(id);
	}

}
