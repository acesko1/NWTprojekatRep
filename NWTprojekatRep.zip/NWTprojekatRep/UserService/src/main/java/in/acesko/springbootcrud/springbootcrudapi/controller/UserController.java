package in.acesko.springbootcrud.springbootcrudapi.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.acesko.springbootcrud.springbootcrudapi.model.User;
import in.acesko.springbootcrud.springbootcrudapi.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private UserService userService;
	
	@GetMapping("/korisnik")
	public List<User> get(){
		return userService.get();
	}
	
	@PostMapping("/korisnik")	
	public User save(@RequestBody User userObj) {
		userService.save(userObj);
		return userObj;
	}
	
	@GetMapping("/korisnik/{id}")
	public User get(@PathVariable int id) {
		User userObj = userService.get(id);
		if(userObj == null) {
			throw new RuntimeException("Korisnik sa id-om:"+id+"nije pronađen");
		}
		return userObj;
	}
	@DeleteMapping("/korisnik/{id}")
	public String delete(@PathVariable int id) {
		userService.delete(id);
		return "Korisnik je obrisan sa id-om:"+id;
	}
	@PutMapping("/korisnik")
	public User update(@RequestBody User userObj) {
		userService.save(userObj);
		return userObj;
	}
//	@RequestMapping(value = "/korisnik", method = RequestMethod.GET)
//	public Korisnik firstPage() {
//
//		Korisnik kor = new Korisnik();
//		kor.setKorisnikID(1);
//		kor.setBrojKartice("12345678");
//		kor.setGodine(20);
//		kor.setIme("Ime");
//		kor.setPrezime("Prezime");
//
//		return kor;
//	}

	
}
